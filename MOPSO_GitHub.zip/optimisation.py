import numpy as np
import re
import pandas as pd
import matplotlib.pyplot as plt
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor
from scipy.stats import gaussian_kde
import seaborn as sns
import shutil
import datetime
import time

# Function: Read the VARIABLES.INC file
def read_variables_file(variables_file):
    # Read the VARIABLES.INC file
    with open(variables_file, 'r') as file:
        lines = file.readlines()

    # Initialise the lists for decision variable names, base values, lower bounds, and upper bounds
    decision_variable_names = []
    base_values = []
    lower_bounds = []
    upper_bounds = []
    decision_variable_units = []

    # Iterate over the lines in the VARIABLES.INC file
    for line in lines:
        # Ignore lines that do not start with a single quote (')
        if not line.strip().startswith("'"):
            continue

        # Extract the decision variable name and values
        parts = line.split()
        decision_variable_name = parts[0][1:-1]  # Extract the name of variables while removing the single quotes
        base_value = float(parts[1])             # Extract the first value to float as the base value
        lower_bound = float(parts[2])            # Extract the second value to float as the lower bound value
        upper_bound = float(parts[3])            # Extract the third value to float as the upper bound value
        decision_variable_unit = parts[6]        # Extract the unit of decision variables

        # Append the extracted values to the corresponding lists
        decision_variable_names.append(decision_variable_name)
        base_values.append(base_value)
        lower_bounds.append(lower_bound)
        upper_bounds.append(upper_bound)
        decision_variable_units.append(decision_variable_unit)
        
    return decision_variable_names, base_values, lower_bounds, upper_bounds, decision_variable_units

# Function: Find global best
def MOPSO(
        run_on_gpu, num_cores, run_simultaneously, run_parallel, # Pass simulation run parameters
        sim_executable_path, input_file_path, input_file_names, # Pass simulation address parameters
        variables_file, variables_file_folder, decision_variable_names, decision_variable_units, base_values, keywords , # Pass variables and keywords
        num_objectives, swarm_size, max_iter, objectives_specification, lower_bounds, upper_bounds, # Specify algorithm parameters
        initial_inertia, end_inertia, nostalgia, sociality, damping_factor, random_seed  # Specify additional settings
        ):
     
    # Set the random seed
    np.random.seed(random_seed)

    # Validate inputs
    if len(lower_bounds) != len(upper_bounds):
        raise ValueError("The lower_bounds and upper_bounds vectors must have the same length.")

    # Define number of decision variables    
    num_variables = len(lower_bounds)

    # Initialise particle positions and velocities
    positions = []
    velocities = []
    positions = initialise_positions(swarm_size, num_variables, lower_bounds, upper_bounds)
    velocities = initialise_velocities(swarm_size, num_variables, lower_bounds, upper_bounds)
    
    # Create a directory to save the plots
    # Get current date and time
    now = datetime.datetime.now()
    # Format as string
    now_str = now.strftime("%Y-%m-%d_%H-%M")
    # Use this string in the directory name
    report_directory = f"{input_file_path}/REPORT_{now_str}"
    if not os.path.exists(report_directory):
        os.makedirs(report_directory)
        
    # Define the filename for the report file storing iterations, objectives, results, and decision variables
    report_file_name = 'mopso_report.csv'
    report_file = f"{report_directory}/{report_file_name}"
    # Create the header row for the report file
    headers = ['Variant', 'Iteration', 'Particle'] + keywords + decision_variable_names + ['Date', 'Start Time', 'End Time', 'Elapsed Time']
    with open(report_file, 'w') as f:
        f.write(','.join(headers) + '\n')             
    
    # Initialise reporting optimal or best positions, objectives, and variants and all solutions
    all_objectives = []
    all_positions = []
    best_positions = []
    best_objectives = []
    best_variants = []
    all_variants = []
    
    # Evaluate the objective functions for initial positions
    row_out = 1
    iteration = -1
    objectives, units, all_variants = evaluate_objectives(num_objectives, positions, variables_file, variables_file_folder, sim_executable_path, input_file_path, input_file_names, keywords, decision_variable_units, row_out, all_variants, iteration, report_directory, report_file, run_on_gpu, run_simultaneously, run_parallel, num_cores=None)
    
    # Report all objectives and positions and the Pareto front
    all_objectives = np.array([]).reshape(0, len(objectives[0]))
    all_objectives = np.vstack([all_objectives, objectives])
    all_positions = np.array([]).reshape(0, len(positions[0]))
    all_positions = np.vstack([all_positions, positions])
    report_allobjectives_and_paretofront(report_directory, all_objectives, objectives_specification, iteration, keywords, units)
    
    # Initialise personal best positions and objectives
    pbest_positions = []
    pbest_objectives = []
    pbest_positions = positions.copy()
    pbest_objectives = objectives.copy()

    # Initialise global best position and objective
    gbest_positions = []
    gbest_objectives = []
    nondominated, _ = pareto_dominance(objectives, objectives_specification)
    gbest_positions = pbest_positions[nondominated]
    gbest_objectives = pbest_objectives[nondominated]
    
    # Iterate until the maximum number of iterations    
    for iteration in range(max_iter):
        # Calculate the inertia weight
        inertia_weight = initial_inertia - (initial_inertia - end_inertia) * (iteration / max_iter)

        # Update velocities and positions
        for i in range(swarm_size):
            rp = np.random.rand(num_variables)
            rg = np.random.rand(num_variables)
            gbest_position = gbest_positions[np.random.randint(gbest_positions.shape[0])]
            
            velocities[i] = damping_factor * (inertia_weight * velocities[i] + nostalgia * rp * (pbest_positions[i] - positions[i]) + sociality * rg * (gbest_position - positions[i]))
            positions[i] = positions[i] + velocities[i]        
            
            # Apply position clamping
            positions[i] = np.maximum(np.minimum(positions[i], upper_bounds), lower_bounds)
        
        # Evaluate the objective functions for the updated positions
        row_out += swarm_size
        objectives, units, all_variants = evaluate_objectives(num_objectives, positions, variables_file, variables_file_folder, sim_executable_path, input_file_path, input_file_names, keywords, decision_variable_units, row_out, all_variants, iteration, report_directory, report_file, run_on_gpu, run_simultaneously, run_parallel, num_cores=None)
        
        # Report all objectives and all positions and the Pareto optimal objectives
        all_objectives = np.vstack([all_objectives, objectives])
        all_positions = np.vstack([all_positions, positions])
        report_allobjectives_and_paretofront(report_directory, all_objectives, objectives_specification, iteration, keywords, units)
        
        # Update personal bests        
        for i in range(swarm_size):
            if dominates(objectives[i], pbest_objectives[i], objectives_specification):
                pbest_positions[i] = positions[i]
                pbest_objectives[i] = objectives[i]
                   
        # Update global bests
        all_positions_best = np.vstack((pbest_positions, gbest_positions))
        all_objectives_best = np.vstack((pbest_objectives, gbest_objectives))        
        nondominated, _ = pareto_dominance(all_objectives_best, objectives_specification)
        gbest_positions = all_positions_best[nondominated]
        gbest_objectives = all_objectives_best[nondominated]
    
    # Return optimal/best positions and objectives and variants
    # Identify the Pareto front
    _, non_dominated_indices = identify_pareto(all_objectives, objectives_specification)
    best_positions = all_positions[non_dominated_indices]
    best_objectives = all_objectives[non_dominated_indices]
    best_variants = np.array(non_dominated_indices) + 1
    
    # Call function reporting MOPSO performance
    report_mopso_performance(report_directory, decision_variable_names, best_positions, num_objectives, best_objectives, all_objectives, best_variants, all_variants, keywords, units)
    
    # Call function deleting RESULTS folder, variables files, and DATA files
    delete_files_and_folder(input_file_path, variables_file_folder, swarm_size, input_file_names)
    
    return best_positions, best_objectives

# Helper functions
# Function: Initialise positions
def initialise_positions(swarm_size, num_variables, lower_bounds, upper_bounds):
    positions = np.zeros((swarm_size, num_variables))
    for i in range(num_variables):
        positions[:, i] = lower_bounds[i] + (upper_bounds[i] - lower_bounds[i]) * np.random.rand(swarm_size)
    return positions

# Function: Initialise velocities
def initialise_velocities(swarm_size, num_variables, lower_bounds, upper_bounds):
    velocities = np.zeros((swarm_size, num_variables))
    for i in range(num_variables):
        range_ = upper_bounds[i] - lower_bounds[i]
        velocities[:, i] = -range_ / 2 + range_ * np.random.rand(swarm_size)
    return velocities

# Function: Evaluate objectives
def evaluate_objectives(num_objectives, positions, variables_file, variables_file_folder, sim_executable_path, input_file_path, input_file_names, keywords, decision_variable_units, row_out, all_variants, iteration, report_directory, report_file, run_on_gpu, run_simultaneously, run_parallel, num_cores=None):
    # Get the swarm size
    swarm_size = positions.shape[0]
    # Initialise the objectives matrix with zeros
    objectives = np.zeros((swarm_size, num_objectives))
        
    if run_parallel:
        # Print running status
        print(f'Iteration: {iteration+1}  Status: running', end = '\r')
        
        # Initialise the timer and time
        current_time = datetime.datetime.now()
        start_time = datetime.datetime.now()
        
        # Run simulation
        # Check if simulations should be run parallel or sequentially
        new_input_file_names = []
        if run_simultaneously:
            for input_file_name in input_file_names:
                # Generate input DATA files and variables files for positions
                input_file_names_unique = write_input_file(positions, variables_file, variables_file_folder, input_file_name, input_file_path, swarm_size, run_parallel)
                new_input_file_names.extend(input_file_names_unique)
            
            # Collect all input file names    
            all_input_file_names = new_input_file_names
            
            # Run simulations parallel for all input file names using a ThreadPoolExecutor
            with ThreadPoolExecutor() as executor:
                # Map the run_simulation function to the input_file_names list
                executor.map(lambda x: run_simulation(x, sim_executable_path, input_file_path, run_on_gpu, num_cores), all_input_file_names)
        
        else:
            for input_file_name in input_file_names:
                # Generate input DATA files and variables files for positions
                input_file_names_unique = write_input_file(positions, variables_file, variables_file_folder, input_file_name, input_file_path, swarm_size, run_parallel)
                
                # Collect unique input file names per input file name
                all_input_file_names = input_file_names_unique
                
                # Run simulations parallel per input file name using a ThreadPoolExecutor
                with ThreadPoolExecutor() as executor:
                    # Map the run_simulation function to the input_file_names list
                    executor.map(lambda x: run_simulation(x, sim_executable_path, input_file_path, run_on_gpu, num_cores), all_input_file_names)
                    
        for i in range(swarm_size):
            # Initialise lists to store objective function values for each input file
            obj1_values = []
            obj2_values = []
            results_out = [] # Initialise results
            results_rest_list = []  # Initialise a list to store the results_rest vectors
            
            # Extract objective function values and results and units from the .rsm file(s)
            for input_file_name in input_file_names:
                # Construct the path to the .rsm file
                rsm_file_path = f"{input_file_path}/RESULTS/{input_file_name.replace('.DATA', f'_{i+1}')}/result.rsm"
                
                # Extract the objective function values from the .rsm file
                obj1, obj2, results_rest, units = parse_output_file(rsm_file_path, keywords)

                # Store the objective function values
                obj1_values.append(obj1)
                obj2_values.append(obj2)
                
                # Append the results_rest vector to the list
                results_rest_list.append(list(results_rest.values()))
                
            # Calculate the final objective function values
            obj1_final = np.mean(obj1_values) if len(input_file_names) > 1 else obj1_values[0]  # average the 1st objective values of the input files
            obj2_final = np.mean(obj2_values) if len(input_file_names) > 1 else obj2_values[0]  # average the 2nd objective values of the input files
            
            # Store the final objective function values in the objectives matrix
            objectives[i,:] = [obj1_final, obj2_final]
            
            # Convert the list of results_rest vectors to a NumPy array
            results_rest_array = np.array(results_rest_list)           
            # Calculate the final values (average of the results_rest vectors)
            if results_rest_array.ndim == 1:  # If it's a 1D array
                results_rest_final = results_rest_array
            elif results_rest_array.ndim == 2:  # If it's a 2D array
                results_rest_final = np.mean(results_rest_array, axis=0) 
            # Store the final result values in the results matrix
            results_out = results_rest_final
            
            # Call function reporting the figure of objectives
            report_objectives_figure(report_directory, objectives, i, iteration, keywords, units)
            
            # Call function reporting the table of objectives, results, and positions 
            report_all_table(keywords, units, results_rest, decision_variable_units, report_file, row_out, iteration, i, objectives, results_out, positions, start_time, current_time)
            
            # Extract all variants numbers
            all_variants.append(row_out)
            
            # Increment the row counter
            row_out += 1

        # Print completion status 
        print(' completed.')
            
    else:
        
        # Loop through all the particles in the swarm
        for i in range(swarm_size):
            # Print running status
            print(f'Variant: {row_out}  Iteration: {iteration+1}  Particle: {i+1}  Status: running', end = '\r')         

            # Initialise the timer and time
            current_time = datetime.datetime.now()
            start_time = datetime.datetime.now()
            
            # Generate variables file for positions[i, :]
            write_input_file(positions[i], variables_file, variables_file_folder=None, input_file_name=None, input_file_path=None, swarm_size=None, run_parallel=None)

            # Run the simulation
            # Check if simulations should be run simultaneously or sequentially
            if run_simultaneously:
                # Run simulations simultaneously using a ThreadPoolExecutor
                with ThreadPoolExecutor() as executor:
                    # Map the run_simulation function to the input_file_names list
                    executor.map(lambda x: run_simulation(x, sim_executable_path, input_file_path, run_on_gpu, num_cores), input_file_names)
            else:
                # Run simulations sequentially 
                for input_file_name in input_file_names:
                    # Call the run_simulation function for each input_file_name
                    run_simulation(input_file_name, sim_executable_path, input_file_path, run_on_gpu, num_cores)
                   
            # Initialise lists to store objective function values for each input file
            obj1_values = []
            obj2_values = []
            results_out = [] # Initialise results
            results_rest_list = []  # Initialise a list to store the results_rest vectors

            # Extract objective function values and results and units from the .rsm file(s)
            for input_file_name in input_file_names:
                # Construct the path to the .rsm file
                rsm_file_path = f"{input_file_path}/RESULTS/{input_file_name.replace('.DATA', '')}/result.rsm"
                
                # Extract the objective function values from the .rsm file
                obj1, obj2, results_rest, units = parse_output_file(rsm_file_path, keywords)

                # Store the objective function values
                obj1_values.append(obj1)
                obj2_values.append(obj2)
                
                # Append the results_rest vector to the list
                results_rest_list.append(list(results_rest.values()))
                
            # Calculate the final objective function values
            obj1_final = np.mean(obj1_values) if len(input_file_names) > 1 else obj1_values[0]  # average the 1st objective values of the input files
            obj2_final = np.mean(obj2_values) if len(input_file_names) > 1 else obj2_values[0]  # average the 2nd objective values of the input files
            # Store the final objective function values in the objectives matrix
            objectives[i,:] = [obj1_final, obj2_final]
            
            # Convert the list of results_rest vectors to a NumPy array
            results_rest_array = np.array(results_rest_list)           
            # Calculate the final values (average of the results_rest vectors)
            if results_rest_array.ndim == 1:  # If it's a 1D array
                results_rest_final = results_rest_array
            elif results_rest_array.ndim == 2:  # If it's a 2D array
                results_rest_final = np.mean(results_rest_array, axis=0) 
            # Store the final result values in the results matrix
            results_out = results_rest_final
            
            # Call function reporting the figure of objectives
            report_objectives_figure(report_directory, objectives, i, iteration, keywords, units)
            
            # Call function reporting the table of objectives, results, and positions 
            report_all_table(keywords, units, results_rest, decision_variable_units, report_file, row_out, iteration, i, objectives, results_out, positions, start_time, current_time)
            
            # Print completion status 
            print(' completed.')        
            
            # Extract all variants numbers
            all_variants.append(row_out)
            
            # Increment the row counter
            row_out += 1    
                      
    return objectives, units, all_variants

# Functions: Parse the decision variables and inpuut DATA files (in case of parallel run) into the simulator
def write_input_file(positions, variables_file, variables_file_folder, input_file_name, input_file_path, swarm_size, run_parallel):
    # This function generates an input data file based on the position vector
    if run_parallel:
       
       # Initialise appending new input file names
       input_file_names_unique = []
       
       for i in range(swarm_size):
           # Construct the unique variables file name
           variables_file_name_unique = f"VARIABLES_{i+1}.INC"    
           variables_file_unique = f"{variables_file_folder}/{variables_file_name_unique}"
           
           positions_unique = positions[i]
           # Read the VARIABLES.INC file
           with open(variables_file, 'r') as file:
               lines = file.readlines()

           # Initialise the output lines list
           output_lines = []
           
           # Initialise the position index
           position_index = 0
           
           # Iterate over the lines in the VARIABLES.INC file
           for line in lines:
               # If the line starts with a single quote ('), update the base value with the position
               if line.strip().startswith("'"):
                   # Split the line into parts
                   parts = line.split()

                   # Replace the base value with the corresponding position value
                   parts[1] = str(positions_unique[position_index])
                   
                   # Increment the position index
                   position_index += 1

                   # Join the parts back together and add a newline character
                   updated_line = ' '.join(parts) + '\n'
                   output_lines.append(updated_line)
               else:
                   # If the line does not start with a single quote ('), keep it unchanged
                   output_lines.append(line)

           # Write the updated VARIABLES.INC file
           with open(variables_file_unique, 'w') as file:
               file.writelines(output_lines)
               
           # Construct the new input_file_name
           input_file_name_unique = input_file_name.replace('.DATA', f'_{i+1}.DATA')
           
           # Construct the new .DATA file for the new variables file for the corresponding position
           data_file_unique = f"{input_file_path}/{input_file_name_unique}"
           
           data_file = f"{input_file_path}/{input_file_name}"
           with open(data_file, 'r') as file:
               data_file_lines = file.readlines()

           # Initialise the output lines list for the .DATA file
           data_file_output_lines = []

           for line in data_file_lines:
               # Replace "VARIABLES.INC" with unique variables file name
               updated_line = line.replace('VARIABLES.INC', f'VARIABLES_{i+1}.INC')
               data_file_output_lines.append(updated_line)

           # Write the updated .DATA file
           with open(data_file_unique, 'w') as file:
               file.writelines(data_file_output_lines)
        
           # Add the unique data file name to the input_file_names_unique list   
           input_file_names_unique.append(input_file_name_unique)

    else:
        
        input_file_names_unique = []
        # Read the VARIABLES.INC file
        with open(variables_file, 'r') as file:
            lines = file.readlines()

        # Initialise the output lines list
        output_lines = []

        # Initialise the position index
        position_index = 0

        # Iterate over the lines in the VARIABLES.INC file
        for line in lines:
            # If the line starts with a single quote ('), update the base value with the position
            if line.strip().startswith("'"):
                # Split the line into parts
                parts = line.split()

                # Replace the base value with the corresponding position value
                parts[1] = str(positions[position_index])

                # Increment the position index
                position_index += 1

                # Join the parts back together and add a newline character
                updated_line = ' '.join(parts) + '\n'
                output_lines.append(updated_line)
            else:
                # If the line does not start with a single quote ('), keep it unchanged
                output_lines.append(line)

        # Write the updated VARIABLES.INC file
        with open(variables_file, 'w') as file:
            file.writelines(output_lines)
            
    return input_file_names_unique

# Function: Run simulations
def run_simulation(input_file_name, sim_executable_path, input_file_path, run_on_gpu, num_cores=None):
    # Create the full input file path by combining the input_file_path and input_file_name
    full_input_file_path = f"{input_file_path}/{input_file_name}"

    # Get the number of available CPU cores
    available_cores = os.cpu_count()

    # If num_cores is not specified or if it's greater than the available cores, use all available cores
    if num_cores is None or num_cores > available_cores:
        num_cores = available_cores

    # Set up the command line arguments
    cmd_args = [sim_executable_path]

    # Run on GPU or CPU
    if run_on_gpu:
        cmd_args.append('--use-gpu')
    else:
        cmd_args.extend(['--cpu-num', str(num_cores)])

    # Generate the RSM file to collect results
    cmd_args.extend(['--ecl-rsm', '--use-rptrst-map-freq'])

    # Direct to the DATA file path
    cmd_args.append(full_input_file_path)

    # Run the simulation
    subprocess.run(cmd_args)    

# Function: Convert scientific values to general values (written for parse_output_file)
def convert_sci_to_general(rsm_file_path):
    # Open the rsm file and read its content
    with open(rsm_file_path, 'r') as file:
        content = file.read()

    # Replace scientific notation with general notation
    def replacement(match):
        # Get the original width of the matched scientific notation
        original_width = len(match.group(1))
        # Get the sign of the exponent (either '+' or '-')
        exponent_sign = match.group(2)
        
        # Apply the appropriate format based on the sign of the exponent
        if exponent_sign == '-':
            # If exponent is negative, format the number with 6 decimal places
            converted_value = '{:.6f}'.format(float(match.group(1)))
        else:
            # If exponent is positive or zero, use the general format
            converted_value = '{:g}'.format(float(match.group(1)))
            
        # Return the converted value with the same width as the original notation
        return converted_value.ljust(original_width)

    # Replace all occurrences of scientific notation with the general notation
    content = re.sub(r'([-+]?\d+\.\d*[eE]([-+]?)\d+)', replacement, content)

    # Write the updated content back to the rsm file
    with open(rsm_file_path, 'w') as file:
        file.write(content)

# Function: Try values only (written for parse_output_file)
def is_number(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

# Function: Parse the objectives, results, and units into MOPSO
def parse_output_file(rsm_file_path, keywords):
                
    # Convert values in scientific format to general format
    convert_sci_to_general(rsm_file_path)
    
    # Parse the data from the file into a DataFrame
    df = pd.read_fwf(
        rsm_file_path,
        header=None,
        widths=[14, 13, 13, 13, 13, 13, 13, 13, 13, 12],
        comment='-',
        skip_blank_lines=True,
        dtype=None,
    )    
    
    # Identify the line number and column number where each keyword can be found in the DataFrame
    keyword_indices = {}
    for keyword in keywords:
        for i, row in df.iterrows():
            if keyword in row.values:
                keyword_line_index = i
                keyword_part_number = row[row == keyword].index[0]
                keyword_indices[keyword] = (keyword_line_index, keyword_part_number)
                break
  
    # Extract the end values, units and multipliers for each keyword
    end_value = [] 
    multiplier = []
    unit = {}
    result = {}
    results = {}
    obj1 = []
    obj1_unit = {}
    obj2 = []
    obj2_unit = {}
    results_rest = {}
    units = {}
    for keyword, (line_index, part_number) in keyword_indices.items():
        unit_line_index = line_index + 1
        unit = df.iloc[unit_line_index, part_number]

        # Identify the line number where the end value for the current keyword is located
        end_value_line_index = None
        for i in range(line_index + 1, len(df)):
            row = df.iloc[i]
            value = row.dropna().values[0]
            if len(row.dropna()) == 1 and is_number(value) and float(value) == 1:
                end_value_line_index = i - 1
                break

        if end_value_line_index is None:
            raise ValueError(f"Couldn't find the end value of the {keyword} column")

        end_value = float(df.iloc[end_value_line_index, part_number])
        
        # Identify the multiplier for the current keyword
        multiplier_line_index = line_index + 2
        multiplier_part = df.iloc[multiplier_line_index, part_number]
        if multiplier_part and '*10**' in str(multiplier_part):
            multiplier = float(str(multiplier_part).split('*10**')[1])
        else:
            multiplier = 0
        
        # Calculate the result for the current keyword and store it together with the unit
        result = end_value * 10 ** multiplier
        results[keyword] = (result, unit)
    
    # Separate the results for the first two objectives and the rest of the keywords
    obj1_keyword, obj2_keyword, *rest_keywords = keywords
    obj1, obj1_unit = results[obj1_keyword] 
    obj2, obj2_unit = results[obj2_keyword] 
    results_rest = {k: results[k][0] for k in rest_keywords} # Extract results for keywords from index 2 until the end
    units = {k: results[k][1] for k in keywords}
    
    # Return the two objectives, the rest of the results and the units
    return obj1, obj2, results_rest, units

# Function: Find dominated objectives
def dominates(a, b, objectives_specification):
    comparisons = [ai <= bi if spec == 'min' else ai >= bi for ai, bi, spec in zip(a, b, objectives_specification)]
    less_than_b = np.all(comparisons)
    strictly_less_than_b = np.any([ai < bi if spec == 'min' else ai > bi for ai, bi, spec in zip(a, b, objectives_specification)])
    dominated = less_than_b and strictly_less_than_b
    return dominated

# Function: Find the Preto front of the dominated objectives
def pareto_dominance(objectives, objectives_specification):
    num_points = objectives.shape[0]
    dominance_matrix = np.zeros((num_points, num_points), dtype=bool)
    for i in range(num_points):
        for j in range(num_points):
            if i != j:
                dominance_matrix[i, j] = dominates(objectives[i, :], objectives[j, :], objectives_specification)

    nondominated_indices = np.where(~np.any(dominance_matrix, axis=1))[0]
    dominated_indices = np.where(np.any(dominance_matrix, axis=1))[0]
    return nondominated_indices, dominated_indices

# Function: Identify the Pareto front 
def identify_pareto(all_objectives, objectives_specification):
    # Count number of items
    population_size = all_objectives.shape[0]
    # Create a NumPy index for scores on the pareto front (zero indexed)
    pareto_front = np.ones(population_size, dtype=bool)
    # Create a list to store the indices of the solutions on the Pareto front
    pareto_front_indices = []
    for i in range(population_size):
        for j in range(population_size):
            if i != j:
                # Check if our 'i' point is dominated by our 'j' point
                if all((all_objectives[j][idx] <= all_objectives[i][idx] if direction == "min" else all_objectives[j][idx] >= all_objectives[i][idx]) for idx, direction in enumerate(objectives_specification)):
                    # j dominates i. Mark our 'i' point as not on the Pareto front
                    pareto_front[i] = 0
                    break   # No need to check other points
        if pareto_front[i]:
            pareto_front_indices.append(i)
    return pareto_front, pareto_front_indices

# Function: Report table file for objectives, positions and results
def report_all_table(keywords, units, results_rest, decision_variable_units, report_file, row_out, iteration, i, objectives, results_out, positions, start_time, current_time):
    # Create the units row for the report file
    if row_out == 1 and iteration == -1 and i == 0:
        units_row = ['', '', ''] + [units[k] for k in keywords[:2]] + [units[k] for k in results_rest.keys()] + decision_variable_units
        while True:
            try:
                with open(report_file, 'a') as f:
                    f.write(','.join(units_row) + '\n')
                break
            except IOError:
                print("Report file is currently open. Code is waiting before trying again. Close the report file immediately.")
                time.sleep(15)
    
    # Write the current iteration, particle number, objectives, results_out, and decision variables to the report file
    while True:
        try:
            with open(report_file, 'a') as f:
                f.write(f'{row_out},{iteration+1},{i+1},')
                f.write(','.join([f'{o:.6f}' for o in objectives[i]]))
                f.write(',')
                f.write(','.join([f'{ro:.6f}' for ro in results_out]))
                f.write(',')
                f.write(','.join([f'{p:.6f}' for p in positions[i]]))
                # Add date, time, start time, end time, and elapsed time
                end_time = datetime.datetime.now()
                elapsed_time = end_time - start_time
                f.write(f',{current_time.date()},{start_time.time().strftime("%H:%M:%S")},{end_time.time().strftime("%H:%M:%S")},{str(elapsed_time).split(".")[0]}')
                f.write('\n')
            break
        except IOError:
            print("Report file is currently open. Code is waiting before trying again. Close the report file immediately.")
            time.sleep(15)

# Function: Report all objectives and the Pareto front
def report_allobjectives_and_paretofront(report_directory, all_objectives, objectives_specification, iteration, keywords, units):
    # Identify the Pareto front
    pareto_front, pareto_front_indices = identify_pareto(all_objectives, objectives_specification)
    # Plot of all solutions and Pareto front
    fig, ax = plt.subplots()
    ax.plot(all_objectives[:, 0], all_objectives[:, 1], 'bo')  # Plot all objectives
    ax.plot(all_objectives[pareto_front, 0], all_objectives[pareto_front, 1], 'ro')  # Highlight the Pareto front
    for i in pareto_front_indices:  # Annotate the Pareto front points with their indices
        ax.annotate(str(i+1), (all_objectives[i, 0], all_objectives[i, 1]))
    ax.set_xlabel(f'{keywords[0]} ({units[keywords[0]]})') # Objective 1 with unit
    ax.set_ylabel(f'{keywords[1]} ({units[keywords[1]]})') # Objective 2 with unit
    ax.set_title('All Solutions and the Pareto Optimal Solutions')
    fig_file_name = f"all_solutions_and_pareto_optimal_solutions_after_iteration_{iteration+1}.png"
    fig_file = f"{report_directory}/{fig_file_name}"
    fig.savefig(fig_file, dpi=300)
    # Show the plot
    plt.show()
    plt.pause(0.1)

    # Write the Pareto front solutions to a report file
    pareto_file_name = f"pareto_optimal_solution_after_iteration_{iteration+1}.csv"
    pareto_file = f"{report_directory}/{pareto_file_name}"
    while True:
        try:
            with open(pareto_file, 'w') as f:
                # Write the headers
                f.write('Variant,Objective 1,Objective 2\n')
                # Write the corresponding keywords
                f.write(','.join([''] + keywords[:2]) + '\n')
                # Write the corresponding units
                f.write(','.join([''] + [units[keyword] for keyword in keywords[:2]]) + '\n')
                # Write the objectives of the Pareto front solutions along with their indices
                for i in pareto_front_indices:
                    f.write(','.join(map(str, [i+1] + list(all_objectives[i]))) + '\n')
            break
        except IOError: 
            print("Pareto file is currently open. Code is waiting before trying again. Close the pareto file immediately.")
            time.sleep(15)

# Function: Report figure for objectives
def report_objectives_figure(report_directory, objectives, i, iteration, keywords, units):
    # Initialise figure and axes
    fig, ax = plt.subplots()
    
    # Update the solutions plot with the current objectives of all particles
    ax.plot(objectives[:i+1, 0], objectives[:i+1, 1], 'bo') # only update the current and previous particles
    
    # Set the labels for the x-axis, y-axis, and the plot title
    ax.set_xlabel(f'{keywords[0]} ({units[keywords[0]]})') # Objective 1 with unit
    ax.set_ylabel(f'{keywords[1]} ({units[keywords[1]]})') # Objective 2 with unit
    ax.set_title('Solutions at Iteration: '+ str(iteration+1))
    
    # Show the plot
    plt.show()
    plt.pause(0.1)
    
# Function: Report MOPSO performance
def report_mopso_performance(report_directory, decision_variable_names, best_positions, num_objectives, best_objectives, all_objectives, best_variants, all_variants, keywords, units):
        
    # Write the best positions to a csv file
    df_best_positions = pd.DataFrame(best_positions, columns=decision_variable_names)
    df_best_positions.index = best_variants
    df_best_positions.index.name = 'Variant'
    df_best_positions.to_csv(f'{report_directory}/best_decision_variables.csv', index=True)
    
    # Plot a heat map of the correlations between the best positions
    # Calculate the correlation matrix for the best positions
    corr = df_best_positions.corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    f, ax = plt.subplots(figsize=(11, 9))
    cmap = sns.diverging_palette(230, 20, as_cmap=True)
    sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
                square=True, linewidths=.5, cbar_kws={"shrink": .5})
    plt.title('Heatmap of Best Positions Correlations')
    plt.savefig(f'{report_directory}/best_decision_variables_heatmap.png', dpi=300)
    plt.close()
    # Save best positions heatmap data to a csv file
    corr_positions = df_best_positions.corr()
    corr_positions.to_csv(f'{report_directory}/best_decision_variables_heatmap.csv', index=False)

    # Plot the decision variables of the best solution
    plt.figure()
    for i in range(len(decision_variable_names)):
        plt.plot(best_variants, [pos[i] for pos in best_positions], marker='o', linestyle='-')
    plt.title('Best Decision Variables')
    plt.xlabel('Variant')
    plt.ylabel('Decision Variable Value')
    plt.legend(decision_variable_names)
    plt.savefig(f'{report_directory}/Best_decision_variables_plot.png', dpi=300)
    plt.close()
    
    # Write the best objectives to a csv file
    df_best_objectives = pd.DataFrame(best_objectives, columns=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    df_best_objectives.index = best_variants
    df_best_objectives.index.name = 'Variant'
    df_best_objectives.to_csv(f'{report_directory}/Pareto_optimal_solutions.csv', index=True)
    
    # Plot the convergence of the objective function value
    # Save best objective function value in each variant for convergence plot
    best_values = [np.min(obj_best) for obj_best in best_objectives]
    plt.figure()
    plt.plot(best_variants, best_values, marker='o', linestyle='-')
    plt.title('Convergence Plot')
    plt.xlabel('Variant')
    plt.ylabel('Best Objective Function Value')
    plt.savefig(f'{report_directory}/convergence_plot.png', dpi=300)
    plt.close()
    # Save best values to a csv file
    df_best_values = pd.DataFrame(best_values, columns=['Best Objective Function Value'])
    df_best_values.index = best_variants
    df_best_values.index.name = 'Variant'
    df_best_values.to_csv(f'{report_directory}/convergence_plot.csv', index=True)

    # Plot a scatterplot matrix of the objective function values of the best solutions
    df_objectives = pd.DataFrame(best_objectives, columns=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    sns.pairplot(df_objectives)
    plt.savefig(f'{report_directory}/scatterplot_matrix_Pareto_optimal_solutions.png', dpi=300)
    plt.close()
    # Save scatterplot matrix data to a csv file
    df_objectives = pd.DataFrame(best_objectives, columns=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    df_objectives.index = best_variants
    df_objectives.index.name = 'Variant'
    df_objectives.to_csv(f'{report_directory}/scatterplot_matrix_Pareto_optimal_solutions.csv', index=True)

    # Plot a box plot of the objective function values of the Pareto optimal solutions
    plt.figure()
    plt.boxplot(best_objectives)
    plt.title('Box Plot - the Pareto Optimal Solutions')
    plt.xlabel('Objective Functions')
    plt.ylabel('Objective Function Value')
    plt.xticks(ticks=range(1, num_objectives+1), labels=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    plt.savefig(f'{report_directory}/box_plot_Pareto_optimal_solutions.png', dpi=300)
    plt.close()
    # Save box plot data to a csv file
    df_box_plot_opt = pd.DataFrame(best_objectives, columns=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    df_box_plot_opt.index = best_variants
    df_box_plot_opt.index.name = 'Variant'
    df_box_plot_opt.to_csv(f'{report_directory}/box_plot_Pareto_optimal_solutions.csv', index=True)
    
    # Plot a box plot of the objective function values of all solutions
    plt.figure()
    plt.boxplot(all_objectives)
    plt.title('Box Plot - All Solutions')
    plt.xlabel('Objective Functions')
    plt.ylabel('Objective Function Value')
    plt.xticks(ticks=range(1, num_objectives+1), labels=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    plt.savefig(f'{report_directory}/box_plot_all_solutions.png', dpi=300)
    plt.close()
    # Save box plot data to a csv file
    df_box_plot_all = pd.DataFrame(all_objectives, columns=[f'{keywords[i]} ({units[keywords[i]]})' for i in range(num_objectives)])
    df_box_plot_all.index = all_variants
    df_box_plot_all.index.name = 'Variant'
    df_box_plot_all.to_csv(f'{report_directory}/box_plot_all_solutions.csv', index=True)
    
    # Plot the cumulative distribution function of the optimal solutions
    num_bins = len(best_objectives)
    plt.figure()
    for i in range(best_objectives.shape[1]):
        plt.hist(best_objectives[:, i], bins=num_bins, density=True, cumulative=True, histtype='step', label=f'{keywords[i]} ({units[keywords[i]]})')
    plt.title('CDF Plot - the Pareto Optimal Solutions')
    plt.xlabel('Objective Function Value')
    plt.ylabel('Normalised Cumulative Distribution Function')
    plt.legend()
    plt.savefig(f'{report_directory}/cdf_optimal_plot.png', dpi=300)
    plt.close()
    # Save the cumulative distribution function of the objective function value
    df_cdf_opt = pd.DataFrame()
    for i in range(best_objectives.shape[1]):
        hist, bin_edges = np.histogram(best_objectives[:, i], bins=num_bins, density=True)
        cdf_opt = np.cumsum(hist)
        cdf_opt_norm = cdf_opt / np.sum(hist)  # normalise cumulative sum to 0-1 range
        df_cdf_opt_i = pd.DataFrame({
            f'Objective {i+1} Function Value: {keywords[i]} ({units[keywords[i]]})': best_objectives[:, i],
            f'Objective {i+1} Edge Value: {keywords[i]} ({units[keywords[i]]})': bin_edges[1:],
            f'Objective {i+1} Cumulative Distribution Function: {keywords[i]} ({units[keywords[i]]})': cdf_opt, 
            f'Objective {i+1} Normalised Cumulative Distribution Function: {keywords[i]} ({units[keywords[i]]})': cdf_opt_norm
            })
        df_cdf_opt = pd.concat([df_cdf_opt, df_cdf_opt_i], axis=1)
    df_cdf_opt.index = best_variants 
    df_cdf_opt.index.name = 'Variant'
    df_cdf_opt.to_csv(f'{report_directory}/cdf_optimal_plot.csv', index=True)

    # Plot the cumulative distribution function of all solutions
    num_bins = len(all_objectives)
    plt.figure()
    for i in range(all_objectives.shape[1]):
        plt.hist(all_objectives[:, i], bins=num_bins, density=True, cumulative=True, histtype='step', label=f'{keywords[i]} ({units[keywords[i]]})')
    plt.title('CDF Plot - All Solutions')
    plt.xlabel('Objective Function Value')
    plt.ylabel('Normalised Cumulative Distribution Function')
    plt.legend()
    plt.savefig(f'{report_directory}/cdf_all_plot.png', dpi=300)
    plt.close()
    # Save the cumulative distribution function of the objective function value
    df_cdf_all = pd.DataFrame()
    for i in range(all_objectives.shape[1]):
        hist, bin_edges = np.histogram(all_objectives[:, i], bins=num_bins, density=True)
        cdf_all = np.cumsum(hist)
        cdf_all_norm = cdf_all / np.sum(hist)  # normalise cumulative sum to 0-1 range
        df_cdf_all_i = pd.DataFrame({
            f'Objective {i+1} Function Value: {keywords[i]} ({units[keywords[i]]})': all_objectives[:, i],
            f'Objective {i+1} Edge Value: {keywords[i]} ({units[keywords[i]]})': bin_edges[1:],
            f'Objective {i+1} Cumulative Distribution Function: {keywords[i]} ({units[keywords[i]]})': cdf_all, 
            f'Objective {i+1} Normalised Cumulative Distribution Function: {keywords[i]} ({units[keywords[i]]})': cdf_all_norm
            })
        df_cdf_all = pd.concat([df_cdf_all, df_cdf_all_i], axis=1)
    df_cdf_all.index = all_variants 
    df_cdf_all.index.name = 'Variant'
    df_cdf_all.to_csv(f'{report_directory}/cdf_all_plot.csv', index=True)
        
    # Plot the probability density function of the optimal solutions
    plt.figure()
    df_pdf_opt = pd.DataFrame()
    for i in range(best_objectives.shape[1]):
        density_opt = gaussian_kde(best_objectives[:, i])
        xs_opt = np.linspace(min(best_objectives[:, i]), max(best_objectives[:, i]), 200)
        plt.plot(xs_opt, density_opt(xs_opt), label=f'{keywords[i]} ({units[keywords[i]]})')
        df_pdf_opt[f'Objective {i+1} Function Value: {keywords[i]} ({units[keywords[i]]})'] = xs_opt
        df_pdf_opt[f'Objective {i+1} Probability Density Function: {keywords[i]} ({units[keywords[i]]})'] = density_opt(xs_opt)
    plt.title('PDF Plot - the Pareto Optimal Solutions')
    plt.xlabel('Objective Function Value')
    plt.ylabel('Probability Density Function')
    plt.legend()
    plt.savefig(f'{report_directory}/pdf_optimal_plot.png', dpi=300)
    plt.close()
    df_pdf_opt.to_csv(f'{report_directory}/pdf_optimal_plot.csv', index=False)    
    
    # Plot the probability density function of all solutions
    plt.figure()
    df_pdf_all = pd.DataFrame()
    for i in range(all_objectives.shape[1]):
        density_all = gaussian_kde(all_objectives[:, i])
        xs_all = np.linspace(min(all_objectives[:, i]), max(all_objectives[:, i]), 200)
        plt.plot(xs_all, density_all(xs_all), label=f'{keywords[i]} ({units[keywords[i]]})')
        df_pdf_all[f'Objective {i+1} Function Value: {keywords[i]} ({units[keywords[i]]})'] = xs_all
        df_pdf_all[f'Objective {i+1} Probability Density Function: {keywords[i]} ({units[keywords[i]]})'] = density_all(xs_all)
    plt.title('PDF Plot - All Solutions')
    plt.xlabel('Objective Function Value')
    plt.ylabel('Probability Density Function')
    plt.legend()
    plt.savefig(f'{report_directory}/pdf_all_plot.png', dpi=300)
    plt.close()
    df_pdf_all.to_csv(f'{report_directory}/pdf_all_plot.csv', index=False)  

# Function: Delete Results folder, variables files, and DATA files    
def delete_files_and_folder(input_file_path, variables_file_folder, swarm_size, input_file_names):
    # Delete the RESULTS directory
    results_dir = os.path.join(input_file_path, 'RESULTS')
    if os.path.exists(results_dir):
        shutil.rmtree(results_dir)

    # Delete the VARIABLES_{i+1}.INC files
    for i in range(swarm_size):
        variables_file_name_unique = f"VARIABLES_{i+1}.INC"
        variables_file_unique = os.path.join(variables_file_folder, variables_file_name_unique)
        if os.path.exists(variables_file_unique):
            os.remove(variables_file_unique)

    # Delete the _{i+1}.DATA files
    for i in range(swarm_size):
        for input_file_name in input_file_names:
            input_file_name_unique = input_file_name.replace('.DATA', f'_{i+1}.DATA')
            data_file_unique = os.path.join(input_file_path, input_file_name_unique)
            if os.path.exists(data_file_unique):
                os.remove(data_file_unique)