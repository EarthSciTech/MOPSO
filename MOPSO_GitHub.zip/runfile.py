from optimisation import read_variables_file, MOPSO  # Import MOPSO and read_variables_file functions from the optimisation.py file

# Define simulation run parameters
run_on_gpu = False  # Set to True to run simulations on GPU, False to run on CPU
num_cores = None  # Set to None to use all available cores, or an integer value for a specific number of cores
run_simultaneously = False # Set to True to run *.DATA files simultaneously
run_parallel = False # Set to True to evaluate all objectives per iteration at once

# Define the path to the simulator executable file
# For example, C:\Users\John\AppData\Local\Programs\RFD\tNavigator\22.4\tNavigator-con-v22.4-4522-g8fec8daa0.exe
sim_executable_path = r"C:\Users\..."

# Define the path to the folder containing the input file(s) for the simulations
# For example: D:\Simulations\3DModels
input_file_path = r"D:\..."

# List of input file names
input_file_names = [
    'FM1_CO1_G1_TS1_TxFFM11_RPCP1.DATA',
    #'FM1_CO1_G1_TS1_TxFFM11_RPCP2.DATA',
    # Add more file names as needed
]

# Define Decision Variables
# Specify the folder and file name and create the full file path to the VARIABLES.INC file
variables_file_folder = r"D:\..."
variables_file_name = "VARIABLES.INC"
variables_file = f"{variables_file_folder}/{variables_file_name}"

#Define Keywords parsing objective functions and results
keywords = [
    "FOPT", "FWIT", "FWPT", "FLPT", "FGPT", "FGIT", "FOIP", "FWIP", "FGIP"
] 

# Call the read_variables_file function from the optimisation.py file
decision_variable_names, base_values, lower_bounds, upper_bounds, decision_variable_units = read_variables_file(variables_file)

# Define the MOPSO problem parameters
num_objectives = 2  # Number of objectives to optimise
swarm_size = 30  # Number of particles in the swarm
max_iter = 30  # Maximum number of iterations for the MOPSO algorithm
objectives_specification = ["min", "max"] # Specify whether each objective should be maximised or minimised. "max" represents maximisation and "min" represents minimisation
lower_bounds = lower_bounds  # Lower bounds for each decision variable
upper_bounds = upper_bounds  # Upper bounds for each decision variable
initial_inertia = 0.742401  # Initial inertia weight for the MOPSO algorithm
end_inertia = 0.627836  # Ending inertia weight for the MOPSO algorithm
nostalgia = 0.74137  # Nostalgia (cognitive) coefficient for the MOPSO algorithm
sociality = 1.054664  # Sociality (social) coefficient for the MOPSO algorithm
damping_factor = 1  # Damping factor for the MOPSO algorithm
random_seed = 0  # Random seed for reproducibility

# Call the MOPSO function from the optimisation.py file
MOPSO(
      run_on_gpu, num_cores, run_simultaneously, run_parallel, # Pass simulation run parameters
      sim_executable_path, input_file_path, input_file_names, # Pass simulation parameters
      variables_file, variables_file_folder, decision_variable_names, decision_variable_units, base_values, keywords , # Pass variables and keywords
      num_objectives, swarm_size, max_iter, objectives_specification, lower_bounds, upper_bounds, # Specify algorithm parameters
      initial_inertia, end_inertia, nostalgia, sociality, damping_factor, random_seed  # Specify additional settings
      )